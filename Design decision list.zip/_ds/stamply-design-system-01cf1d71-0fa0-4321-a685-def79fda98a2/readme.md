# Stamply — Design System

> **Statut : identité & fondations proposées — en attente de validation avant de produire les pages.**

Stamply est une application **SaaS B2B** de **carte de visite digitale + carte de fidélité** qui s'installe dans **Apple Wallet** et **Google Wallet**. Elle s'adresse aux **artisans, coiffeurs, barbiers, fleuristes et petits commerçants** — souvent peu à l'aise avec la technologie. L'interface doit donc être **ultra simple, rassurante, moderne mais chaleureuse** — jamais froide.

Le produit a **deux faces** :

1. **Dashboard commerçant** (desktop + tablette) — le commerçant crée sa carte, gère ses infos, visualise ses stats, télécharge son QR code, gère son abonnement.
2. **Page client final** (mobile only) — le client scanne un QR code, installe la carte dans son Wallet, reçoit une confirmation.

## Sources
Aucun codebase ni Figma fourni — **identité créée de zéro** à partir du brief produit (juin 2026). Nom de marque retenu : **Stamply**. À mettre à jour si une marque/charte existante est communiquée.

---

## CONTENT FUNDAMENTALS — ton & écriture

- **Langue : français**, registre **tutoiement chaleureux côté marketing**, mais l'UI du dashboard parle au commerçant à la **2ᵉ personne directe et rassurante** (« Votre carte », « Vous y êtes presque »). On reste **vouvoiement dans le produit** (pro, respectueux), tutoiement réservé aux moments d'encouragement (« Bravo ! »).
- **Clair et concret, zéro jargon.** On dit « carte », « tampon », « scan », « installer dans le Wallet » — pas « provisioning », « pass », « endpoint ».
- **Phrases courtes, verbes d'action.** Les boutons commencent par un verbe : *Créer ma carte*, *Télécharger le QR*, *Voir mes stats*, *Installer dans Wallet*.
- **Casing :** Phrase case partout (titres, boutons, labels). Pas de Title Case anglais. Les eyebrows/overlines sont en MAJUSCULES espacées (`STATISTIQUES · 30 JOURS`).
- **Rassurant par défaut.** Les états vides et erreurs guident sans culpabiliser : « Aucun scan pour l'instant — partagez votre QR pour démarrer. »
- **Chiffres en français :** espace fine comme séparateur de milliers (`1 248`), `10ᵉ` en exposant, `€` après le montant (`9 €/mois`).
- **Emoji : non** dans le produit. La chaleur vient des couleurs, des formes arrondies et de la copy — pas des emoji.
- **Exemples de voix :**
  - Onboarding : « Bienvenue ! Créons votre première carte en 2 minutes. »
  - Succès : « C'est fait. Votre carte est dans le Wallet. »
  - Erreur : « Ce numéro ne semble pas valide. Vérifiez et réessayez. »
  - Vide : « Votre carte est prête. Partagez votre QR code pour récolter vos premiers scans. »

---

## VISUAL FOUNDATIONS

**Vibe générale :** chaleureux, premium, artisanal-moderne. Beaucoup de **blanc** (un blanc crème, pas clinique), une **couleur signature affirmée** (corail), une typographie à caractère. L'inverse du bleu corporate.

### Couleurs
- **Primaire — Coral « Stamp » `#F1573D`.** Mémorable, énergique, chaleureuse ; évoque l'encre d'un tampon. Utilisée pour l'action principale (1 seule par écran), accents, états actifs.
- **Accent — Petrol Teal `#137A6E`.** Complément froid maîtrisé : data-viz, liens secondaires, badges info. Utilisé avec parcimonie.
- **Neutres — « Stone » chauds.** Du crème canvas `#FBF7F2` à l'encre `#1F1B18`. Jamais de gris bleuté/froid : tous les neutres ont une pointe de chaleur.
- **Sémantiques :** succès `#1F9D63`, attention `#E5A100` (miel), erreur `#D42A35` (cramoisi, distinct du corail), info = teal. Chaque couleur a un *tint* (fond) et un *fg* (texte) pour les badges/alertes.

### Typographie
- **Display : Bricolage Grotesque** (700–800) — titres, gros chiffres. Caractère, chaleur, modernité. Tracking serré (`-0.03em`).
- **UI / Body : Hanken Grotesk** (400–600) — formulaires, texte, labels. Très lisible, ronde, amicale.
- **Mono : JetBrains Mono** — stats, identifiants, numéros, valeurs de champs Wallet.
- Échelle 16px base, de `caption 12` à `display-2xl 56`.

### Espace, rayons, ombres
- **Échelle 4px.** Respiration généreuse (padding cartes 24px, gouttières 24px).
- **Rayons arrondis mais sobres :** 8/12/16/20/28px + pill pour boutons et badges. La carte Wallet utilise **16px** (rayon réel d'un pass).
- **Ombres douces, teintées d'encre chaude** (`rgba(31,27,24,…)`), jamais de noir pur. 5 niveaux + une ombre spéciale `--shadow-wallet` plus profonde pour faire « flotter » le pass.

### Fonds & textures
- Fond d'app **crème uni** (`--surface-canvas`). **Pas de gradients décoratifs**, pas de motifs chargés. Le contraste vient des cartes blanches posées sur le crème.
- Surfaces sombres (`--ink`) réservées : pass Wallet par défaut, sections « hero » ponctuelles, footer.

### Animation & états
- **Easing par défaut `--ease-out` (cubic-bezier(.22,.78,.32,1))**, durées 90–340ms. Calme et net.
- **`--ease-spring`** réservé aux moments de **célébration/succès** (le pouce du switch, l'installation réussie) — un léger rebond, jamais sur la chrome.
- **Hover :** assombrissement de la couleur (corail 500→600) ou fond `--surface-hover` pour les surfaces neutres ; les cartes interactives se **soulèvent** (`translateY(-2px)` + ombre plus large).
- **Press :** `translateY(1px) scale(.99)` sur boutons, `scale(.94)` sur icon buttons (retour tactile).
- **Focus :** anneau corail `--focus-ring` (3px) visible au clavier.
- `prefers-reduced-motion` : toutes les durées tombent à 0.

### Bordures, transparence, blur
- **Hairlines 1px** en stone-100/200. Pas de bordures épaisses ni d'accent-border coloré à gauche (anti-pattern à éviter).
- Transparence/blur : usage minimal — overlays de dialogues (scrim encre ~50%), header collant éventuel. Pas de glassmorphism partout.

### Cartes
Surface blanche, rayon 16px, ombre `--shadow-sm` par défaut, bordure `--border-subtle` quasi invisible. Variantes `flat` (bordure seule) et `raised` (ombre md). Les tuiles de stats utilisent `raised`.

---

## ICONOGRAPHY
- **Système : [Lucide](https://lucide.dev)** — trait 2px, bouts arrondis, géométrie simple. Cohérent avec la rondeur de la marque. Chargé via CDN dans les pages (`https://unpkg.com/lucide`), ou en SVG inline pour les specimens.
- **Style :** outline uniquement (jamais de fill bicolore), taille 18–20px dans l'UI, `currentColor` pour hériter de la couleur du contexte.
- **Pas d'emoji** comme icônes. Pas de caractères unicode détournés.
- **Logo :** mark géométrique « tampon » (carré arrondi + anneau perforé) + wordmark Bricolage Grotesque 800. Voir `components/brand/Logo.jsx`.
- ⚠️ *Lucide est une substitution par défaut (aucun set d'icônes n'a été fourni). À confirmer / remplacer si vous avez un jeu d'icônes maison.*

---

## ⚠️ Substitutions à valider
- **Polices** chargées depuis **Google Fonts** (`tokens/fonts.css`). Pour la prod Node.js / offline, self-hostez les `.woff2` et remplacez l'`@import` par des règles `@font-face`. Merci de confirmer Bricolage Grotesque + Hanken Grotesk + JetBrains Mono, ou de fournir vos polices.
- **Icônes** : Lucide par défaut (voir ci-dessus).
- **QR code** dans `WalletPass` : motif **placeholder non scannable** (purement visuel). Le vrai QR sera généré côté serveur.

---

## INDEX — manifeste du dépôt

| Chemin | Rôle |
|---|---|
| `styles.css` | **Point d'entrée global** (uniquement des `@import`). Les consommateurs lient ce fichier. |
| `tokens/colors.css` | Couleurs : échelles + alias sémantiques. |
| `tokens/typography.css` | Familles, poids, échelle, classes utilitaires `.t-*`. |
| `tokens/spacing.css` | Échelle d'espace 4px + variables de layout. |
| `tokens/radius.css` | Rayons + échelle d'ombres (dont `--shadow-wallet`). |
| `tokens/motion.css` | Durées, easings, transitions. |
| `tokens/fonts.css` | Webfonts (Google Fonts). |
| `tokens/base.css` | Reset + styles d'éléments de base. |
| `components/components.css` | Styles (classes + états) des primitives. |
| `components/buttons/` | `Button`, `IconButton` |
| `components/forms/` | `Input`, `Textarea`, `Select`, `Switch` |
| `components/data-display/` | `Card`, `Badge`, `Avatar` |
| `components/brand/` | `Logo`, `WalletPass` (preview Apple Wallet) |
| `foundations/*.card.html` | Specimens (couleurs, type, espace, rayons) — onglet Design System. |
| `charte-graphique.html` | **Charte graphique** résumée en une page. |
| `SKILL.md` | Métadonnées Agent Skill (usage hors plateforme). |

### Composants disponibles
`Button` · `IconButton` · `Input` · `Textarea` · `Select` · `Switch` · `Card` · `Badge` · `Avatar` · `Logo` · `WalletPass`

### À venir (après validation)
UI kits **Dashboard commerçant** (onboarding, éditeur de carte + preview live, stats, QR, paramètres/abonnement) et **Client final mobile** (installation, confirmation).
