/* @ds-bundle: {"format":3,"namespace":"StamplyDesignSystem_01cf1d","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"WalletPass","sourcePath":"components/brand/WalletPass.jsx"},{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"IconButton","sourcePath":"components/buttons/IconButton.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"0997ce4b3a31","components/brand/WalletPass.jsx":"bc59b60e25b5","components/buttons/Button.jsx":"0eced00b3752","components/buttons/IconButton.jsx":"eaab3f0f770d","components/data-display/Avatar.jsx":"6121c6cad7ef","components/data-display/Badge.jsx":"d7d329990cd0","components/data-display/Card.jsx":"7cdd2795d88f","components/forms/Input.jsx":"0343bc9d94a7","components/forms/Select.jsx":"40d506f021c8","components/forms/Switch.jsx":"9e0afbf10289","components/forms/Textarea.jsx":"bf79648003f6"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.StamplyDesignSystem_01cf1d = window.StamplyDesignSystem_01cf1d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Stamply logo. A simple "stamp" mark (rounded square with a punched dot)
 * next to the wordmark. The mark is intentionally geometric so it stays
 * crisp at any size and works in one color.
 */
function Logo({
  variant = "full",
  // full | mark | wordmark
  size = 28,
  color = "var(--ink)",
  markColor = "var(--brand)",
  className = "",
  ...rest
}) {
  const mark = /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 32 32",
    fill: "none",
    "aria-hidden": "true",
    style: {
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "28",
    height: "28",
    rx: "9",
    fill: markColor
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "16",
    cy: "16",
    r: "7.5",
    fill: "none",
    stroke: "var(--white, #fff)",
    strokeWidth: "2.6"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "16",
    cy: "16",
    r: "2.4",
    fill: "var(--white, #fff)"
  }));
  const wordmark = /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: size * 0.86,
      letterSpacing: "-0.03em",
      color,
      lineHeight: 1
    }
  }, "Stamply");
  if (variant === "mark") return /*#__PURE__*/React.createElement("span", _extends({
    className: className
  }, rest), mark);
  if (variant === "wordmark") return /*#__PURE__*/React.createElement("span", _extends({
    className: className
  }, rest), wordmark);
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: size * 0.3
    }
  }, rest), mark, wordmark);
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/brand/WalletPass.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Deterministic QR-like module grid (a realistic-looking placeholder, not a
   scannable code). Renders finder squares in 3 corners + pseudo-random modules. */
function QrMock({
  size = 96,
  fg = "#1F1B18",
  seed = 7
}) {
  const N = 21;
  const cell = size / N;
  let s = seed * 2654435761;
  const rnd = () => (s = s * 1103515245 + 12345 & 0x7fffffff) / 0x7fffffff;
  const inFinder = (r, c) => {
    const f = (br, bc) => r >= br && r < br + 7 && c >= bc && c < bc + 7;
    return f(0, 0) || f(0, N - 7) || f(N - 7, 0);
  };
  const mods = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (!inFinder(r, c) && rnd() > 0.55) mods.push(/*#__PURE__*/React.createElement("rect", {
    key: `${r}-${c}`,
    x: c * cell,
    y: r * cell,
    width: cell,
    height: cell,
    fill: fg
  }));
  const finder = (x, y) => /*#__PURE__*/React.createElement("g", {
    key: `f${x}${y}`
  }, /*#__PURE__*/React.createElement("rect", {
    x: x,
    y: y,
    width: cell * 7,
    height: cell * 7,
    fill: fg
  }), /*#__PURE__*/React.createElement("rect", {
    x: x + cell,
    y: y + cell,
    width: cell * 5,
    height: cell * 5,
    fill: "#fff"
  }), /*#__PURE__*/React.createElement("rect", {
    x: x + cell * 2,
    y: y + cell * 2,
    width: cell * 3,
    height: cell * 3,
    fill: fg
  }));
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: `0 0 ${size} ${size}`,
    "aria-label": "QR code",
    role: "img"
  }, /*#__PURE__*/React.createElement("rect", {
    width: size,
    height: size,
    fill: "#fff"
  }), mods, finder(0, 0), finder((N - 7) * cell, 0), finder(0, (N - 7) * cell));
}
function Field({
  label,
  value,
  align = "left",
  fg
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: align,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 10,
      fontWeight: 600,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      color: fg,
      opacity: 0.62,
      marginBottom: 3,
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 600,
      color: fg,
      lineHeight: 1.15,
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, value));
}

/**
 * Apple-Wallet-style store-card preview. Mirrors a real pass: logo row,
 * primary field, secondary fields, and a QR strip on a white footer.
 */
function WalletPass({
  shopName = "Salon Léa",
  profession = "Coiffeur · Lyon",
  logoSrc = null,
  bg = "var(--ink)",
  fg = "#FFFFFF",
  headerField = {
    label: "Tampons",
    value: "6 / 10"
  },
  primaryField = {
    label: "Carte de fidélité",
    value: "10ᵉ visite offerte"
  },
  secondaryFields = [{
    label: "Téléphone",
    value: "04 78 00 00 00"
  }, {
    label: "Membre depuis",
    value: "Mars 2026"
  }],
  showQr = true,
  qrSeed = 7,
  width = 320,
  className = "",
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    style: {
      width,
      borderRadius: "var(--radius-wallet)",
      background: bg,
      boxShadow: "var(--shadow-wallet)",
      overflow: "hidden",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "16px 18px 14px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 7,
      flex: "0 0 auto",
      background: logoSrc ? "transparent" : "rgba(255,255,255,0.16)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden"
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      color: fg,
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: 13
    }
  }, shopName[0])), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 14,
      color: fg,
      letterSpacing: "-0.01em",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, shopName)), headerField && /*#__PURE__*/React.createElement(Field, _extends({}, headerField, {
    align: "right",
    fg: fg
  }))), primaryField && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Field, _extends({}, primaryField, {
    fg: fg
  }))), secondaryFields?.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      justifyContent: "space-between"
    }
  }, secondaryFields.map((f, i) => /*#__PURE__*/React.createElement(Field, _extends({
    key: i
  }, f, {
    fg: fg,
    align: i === secondaryFields.length - 1 && secondaryFields.length > 1 ? "right" : "left"
  }))))), showQr && /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      padding: "14px 0 16px",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement(QrMock, {
    size: 104,
    seed: qrSeed
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 10,
      letterSpacing: "0.12em",
      color: "var(--stone-500)"
    }
  }, "STAMPLY \xB7 ", profession)));
}
Object.assign(__ds_scope, { WalletPass });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/WalletPass.jsx", error: String((e && e.message) || e) }); }

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Stamply primary action button. Pill-shaped, coral by default.
 */
function Button({
  children,
  variant = "primary",
  // primary | secondary | ghost | accent | danger
  size = "md",
  // sm | md | lg
  block = false,
  loading = false,
  disabled = false,
  iconLeft = null,
  iconRight = null,
  type = "button",
  className = "",
  ...rest
}) {
  const cls = ["sty-btn", variant !== "primary" && `sty-btn--${variant}`, size !== "md" && `sty-btn--${size}`, block && "sty-btn--block", loading && "sty-btn--loading", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls,
    disabled: disabled || loading
  }, rest), iconLeft, children && /*#__PURE__*/React.createElement("span", null, children), iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Square icon-only button for toolbars, cards and nav.
 */
function IconButton({
  children,
  size = "md",
  // sm | md
  solid = false,
  label,
  className = "",
  ...rest
}) {
  const cls = ["sty-iconbtn", size === "sm" && "sty-iconbtn--sm", solid && "sty-iconbtn--solid", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cls,
    "aria-label": label
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Avatar with image or initials fallback. */
function Avatar({
  src,
  name = "",
  size = "md",
  // sm | md | lg
  square = false,
  className = "",
  ...rest
}) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map(p => p[0]?.toUpperCase()).join("");
  const cls = ["sty-avatar", size !== "md" && `sty-avatar--${size}`, square && "sty-avatar--square", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name
  }) : initials || "?");
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Small status / category pill. */
function Badge({
  children,
  variant = "neutral",
  // neutral | brand | success | warning | error | info
  dot = false,
  icon = null,
  className = "",
  ...rest
}) {
  const cls = ["sty-badge", variant !== "neutral" && `sty-badge--${variant}`, dot && "sty-badge--dot", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), icon, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Generic surface container. */
function Card({
  children,
  variant = "default",
  // default | flat | raised
  interactive = false,
  as = "div",
  className = "",
  ...rest
}) {
  const Tag = as;
  const cls = ["sty-card", variant !== "default" && `sty-card--${variant}`, interactive && "sty-card--interactive", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Labelled text input with hint / error states and optional leading icon.
 */
function Input({
  label,
  hint,
  error,
  required = false,
  iconLeft = null,
  id,
  className = "",
  ...rest
}) {
  const inputId = id || (label ? `in-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  const input = /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    className: ["sty-input", error && "sty-input--error", className].filter(Boolean).join(" "),
    "aria-invalid": !!error
  }, rest));
  return /*#__PURE__*/React.createElement("div", {
    className: "sty-field"
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "sty-field__label",
    htmlFor: inputId
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "sty-field__req"
  }, "*")), iconLeft ? /*#__PURE__*/React.createElement("div", {
    className: "sty-inputwrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sty-inputwrap__icon"
  }, iconLeft), input) : input, error ? /*#__PURE__*/React.createElement("span", {
    className: "sty-field__error"
  }, error) : hint && /*#__PURE__*/React.createElement("span", {
    className: "sty-field__hint"
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Native select styled to match Stamply inputs. */
function Select({
  label,
  hint,
  error,
  required = false,
  options = [],
  placeholder,
  id,
  className = "",
  ...rest
}) {
  const selId = id || (label ? `sel-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    className: "sty-field"
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "sty-field__label",
    htmlFor: selId
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "sty-field__req"
  }, "*")), /*#__PURE__*/React.createElement("select", _extends({
    id: selId,
    className: ["sty-select", error && "sty-select--error", className].filter(Boolean).join(" "),
    "aria-invalid": !!error,
    defaultValue: placeholder ? "" : undefined
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), options.map(o => {
    const value = typeof o === "string" ? o : o.value;
    const label = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, label);
  })), error ? /*#__PURE__*/React.createElement("span", {
    className: "sty-field__error"
  }, error) : hint && /*#__PURE__*/React.createElement("span", {
    className: "sty-field__hint"
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** On/off toggle with optional label. */
function Switch({
  checked,
  defaultChecked,
  onChange,
  label,
  disabled = false,
  id,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ["sty-switch", disabled && "sty-switch--disabled"].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch",
    id: id,
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "sty-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sty-switch__thumb"
  })), label && /*#__PURE__*/React.createElement("span", {
    className: "sty-switch__label"
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Multi-line text field, same label/hint/error contract as Input. */
function Textarea({
  label,
  hint,
  error,
  required = false,
  id,
  className = "",
  ...rest
}) {
  const taId = id || (label ? `ta-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    className: "sty-field"
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "sty-field__label",
    htmlFor: taId
  }, label, required && /*#__PURE__*/React.createElement("span", {
    className: "sty-field__req"
  }, "*")), /*#__PURE__*/React.createElement("textarea", _extends({
    id: taId,
    className: ["sty-textarea", error && "sty-textarea--error", className].filter(Boolean).join(" "),
    "aria-invalid": !!error
  }, rest)), error ? /*#__PURE__*/React.createElement("span", {
    className: "sty-field__error"
  }, error) : hint && /*#__PURE__*/React.createElement("span", {
    className: "sty-field__hint"
  }, hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.WalletPass = __ds_scope.WalletPass;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

})();
